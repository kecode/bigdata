## 1 搭建zookeeper

​	hadoop做高可用时需要使用zookeeper,所以在此先安装它.

### 1.1 配置zookeeper

(1).下载zookeeper-3.4.14.tar

(2).解压到/opt/bigdata/zookeeper目录下(如果目录不存在可以使用命令:mkdir -p /opt/bigdata/zookeeper 创建)

(3).配置zookeeper的环境变量如下

```shell
# .bash_profile

# Get the aliases and functions
if [ -f ~/.bashrc ]; then
	. ~/.bashrc
fi

# User specific environment and startup programs
ZOOKEEPER_HOME=/opt/bigdata/zookeeper/zookeeper-3.4.14
JAVA_HOME=/usr/java/jdk1.8.0_211-amd64/
PATH=$PATH:$HOME/bin:$JAVA_HOME/bin:$ZOOKEEPER_HOME/bin

export JAVA_HOME
export ZOOKEEPER_HOME

export PATH
```

**最后记得source  /root/.bash_profile**下使得配置的环境变量生效

(4).配置zookeeper.在上一步目录下，将目录切换到zookeeper目录下的conf目录下复制zoo_sample.cfg文件为zoo.cfg.

![1555663544411](../../../../01%20HK/gitlab/newb/00-%E5%A4%A7%E6%95%B0%E6%8D%AE%E5%B9%B3%E5%8F%B0%E5%AE%89%E8%A3%85/%E5%A4%A7%E6%95%B0%E6%8D%AE%E7%8E%AF%E5%A2%83%E5%AE%89%E8%A3%85/assets/1555663544411.png)

修改dataDir的值为 dataDir=/var/lib/zookeeper,在文件的末尾添加如下配置:

server.1=node2:2888:3888
server.2=node3:2888:3888
server.3=node4:2888:3888

```shell
# The number of milliseconds of each tick
tickTime=2000
# The number of ticks that the initial 
# synchronization phase can take
initLimit=10
# The number of ticks that can pass between 
# sending a request and getting an acknowledgement
syncLimit=5
# the directory where the snapshot is stored.
# do not use /tmp for storage, /tmp here is just 
# example sakes.
dataDir=/var/lib/zookeeper
# the port at which the clients will connect
clientPort=2181
# the maximum number of client connections.
# increase this if you need to handle more clients
#maxClientCnxns=60
#
# Be sure to read the maintenance section of the 
# administrator guide before turning on autopurge.
#
# http://zookeeper.apache.org/doc/current/zookeeperAdmin.html#sc_maintenance
#
# The number of snapshots to retain in dataDir
#autopurge.snapRetainCount=3
# Purge task interval in hours
# Set to "0" to disable auto purge feature
#autopurge.purgeInterval=1
server.1=node2:2888:3888
server.2=node3:2888:3888
server.3=node4:2888:3888
```

在节点node2,node3,node4对应的/var/lib/zookeeper目录下(dataDir配置的目录/var/lib/zookeeper)创建myid文件,几个文件内容一次问1,2,3

**node2**

```shell
[root@node2 zookeeper]# pwd
/var/lib/zookeeper
[root@node2 zookeeper]# cat myid 
1
[root@node2 zookeeper]# 
```

**node3**

```
[root@node3 zookeeper]# ll
total 8
-rw-r--r--. 1 root root  2 Apr 19 04:37 myid
drwxr-xr-x. 2 root root 47 Apr 19 04:38 version-2
-rw-r--r--. 1 root root  5 Apr 19 04:37 zookeeper_server.pid
[root@node3 zookeeper]# cat myid 
2
[root@node3 zookeeper]# 
```

**node4**

```shell
[root@node4 zookeeper]# ll
total 8
-rw-r--r--. 1 root root  2 Apr 19 04:36 myid
drwxr-xr-x. 2 root root 73 Apr 19 04:38 version-2
-rw-r--r--. 1 root root  5 Apr 19 04:38 zookeeper_server.pid
[root@node4 zookeeper]# cat myid 
3
[root@node4 zookeeper]# 
```

### 1.2 启动zookeeper

每个安装zookeeper的节点都需要单独启动

```shell
#在node2节点执行zkServer.sh start启动zookeeper
[root@node2 zookeeper]# zkServer.sh start
ZooKeeper JMX enabled by default
Using config: /opt/bigdata/zookeeper/zookeeper-3.4.14/bin/../conf/zoo.cfg
Starting zookeeper ... STARTED
[root@node2 zookeeper]# zkServer.sh status
ZooKeeper JMX enabled by default
Using config: /opt/bigdata/zookeeper/zookeeper-3.4.14/bin/../conf/zoo.cfg
Mode: follower
[root@node2 zookeeper]# 
```

```shell
#在node3节点执行zkServer.sh start启动zookeeper
[root@node3 zookeeper]# zkServer.sh start
ZooKeeper JMX enabled by default
Using config: /opt/bigdata/zookeeper/zookeeper-3.4.14/bin/../conf/zoo.cfg
Starting zookeeper ... STARTED
[root@node3 zookeeper]# zkServer.sh status
ZooKeeper JMX enabled by default
Using config: /opt/bigdata/zookeeper/zookeeper-3.4.14/bin/../conf/zoo.cfg
Mode: leader
[root@node3 zookeeper]#  
```

```shell
#在node4节点执行zkServer.sh start启动zookeeper
[root@node4 ~]# zkServer.sh start
ZooKeeper JMX enabled by default
Using config: /opt/bigdata/zookeeper/zookeeper-3.4.14/bin/../conf/zoo.cfg
Starting zookeeper ... STARTED
[root@node4 ~]# zkServer.sh status
ZooKeeper JMX enabled by default
Using config: /opt/bigdata/zookeeper/zookeeper-3.4.14/bin/../conf/zoo.cfg
Mode: follower
[root@node4 ~]# 
```

