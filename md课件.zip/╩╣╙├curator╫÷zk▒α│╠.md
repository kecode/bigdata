 curator框架操作zookeeper

[下载curator]: https://mvnrepository.com/search?q=org.apache.curator

![1558428489573](/assets/1558428489573.png)

![点击buudle下载](assets/1558428613907.png)